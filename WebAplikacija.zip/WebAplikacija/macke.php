
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link rel="stylesheet" href="styleZivotinje.css">
<link rel="stylesheet" href="Stilovi/style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<title>UDOMI ME</title>
</head>
<body>
<nav  id="navbar_top" class="navbar navbar-expand-lg navbar-light p-md-2" style="background-color:   rgb(176, 128, 225);">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="Slike/ikonica.jpg" alt="Logo" width="60" height="60">UDOMI ME
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <div class="mx-auto"></div>
        <ul class="navbar-nav">
        <li class="nav-item" >
            <a  class="link" href="pocetna.php">POČETNA</a>
          </li>
          <li class="nav-item">
            <a class="link" href="zastoudomiti.php">ZAŠTO UDOMITI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="psi.php">PSI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="macke.php">MAČKE</a>
          </li>
          <li class="nav-item">
            <a class="link " href="udomi.php">UDOMI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="uvjetiUdomljavanja.php">UVJETI O UDOMLJAVANJU</a>
          </li>
        </ul>
      </div>
    </div>
</nav>

<div class="container-fluid">

  <div class="row">

    <div class="col-lg-6  py-0 px-0">
     <div class="hover">
     <img class="w-100  " src="Slike/SlikeMačke/Mačka1.jpg" alt="">
         <div class="content">
         <a class="info" href="MačkeOpis/Macka1.php">OPIS</a>
          </div>
      </div>
    </div>


    <div class="col-lg-6  py-0 px-0">
     <div class="hover">
     <img class="w-100  " src="Slike/SlikeMačke/Mačka2a.jpg" alt="">
         <div class="content">
         <a class="info" href="MačkeOpis/Macka2.php">OPIS</a>
          </div>
      </div>
    </div>

    <div class="col-lg-6  py-0 px-0">
     <div class="hover">
     <img class="w-100  " src="Slike/SlikeMačke/Mačka3.jpg" alt="">
         <div class="content">
         <a class="info" href="MačkeOpis/Macka3.php">OPIS</a>
          </div>
      </div>
    </div>

    <div class="col-lg-6  py-0 px-0">
     <div class="hover">
     <img class="w-100  " src="Slike/SlikeMačke/Mačka4.jpg" alt="">
         <div class="content">
         <a class="info" href="MačkeOpis/Macka4.php">OPIS</a>
          </div>
      </div>
    </div>

    <div class="col-lg-6  py-0 px-0">
     <div class="hover">
     <img class="w-100  " src="Slike/SlikeMačke/Mačka5.jpg" alt="">
         <div class="content">

         <a class="info" href="MačkeOpis/Macka5.php">OPIS</a>
          </div>
      </div>
    </div>

    <div class="col-lg-6  py-0 px-0">
     <div class="hover">
     <img class="w-100  " src="Slike/SlikeMačke/Mačka6.jpg" alt="">
         <div class="content">

         <a class="info" href="MačkeOpis/Macka6.php">OPIS</a>
          </div>
      </div>
    </div>

  </div>
</div>
</body>
<script>
window.addEventListener('scroll', function() 
{
      if (window.scrollY > 50) 
      {
        document.getElementById('navbar_top').classList.add('fixed-top');
        navbar_height = document.querySelector('.navbar').offsetHeight;
        document.body.style.paddingTop = navbar_height + 'px';
      } else 
      {
        document.getElementById('navbar_top').classList.remove('fixed-top');
        document.body.style.paddingTop = '0';
      } 
});
</script>

</html> 

  
  
  
  
  