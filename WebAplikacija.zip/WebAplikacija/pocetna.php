<?php 
session_start();  
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link rel="stylesheet" type="text/css" href="Stilovi/style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<title>UDOMI ME</title>
</head>
<body >
<nav class="navbar fixed-top navbar-expand-lg navbar-light p-md-2"style=" background:rgb(176, 128, 225)"
  >
    <div class="container-fluid">
      <a class="navbar-brand" href="#" style="font-family: Georgia, 'Times New Roman', Times, serif;">
        <img  src="Slike/ikonica.jpg" alt="Logo" width="60" height="60">UDOMI ME
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <div class="mx-auto"></div>
        <ul class="navbar-nav">
          <li class="nav-item" >
            <a  class="link" href="pocetna.php">POČETNA</a>
          </li>
          <li class="nav-item">
            <a class="link" href="zastoudomiti.php">ZAŠTO UDOMITI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="psi.php">PSI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="macke.php">MAČKE</a>
          </li>
          <li class="nav-item">
            <a class="link " href="udomi.php">UDOMI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="uvjetiUdomljavanja.php">UVJETI O UDOMLJAVANJU</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<main>
  <div class="w-100 vh-100 d-flex justify-content-md-center align-items-center">
    <div class="content text-center">
      <h1 >DOBRODOŠLI</h1>
      <p class="paragraph">Dobrodošli na web stranicu za udomljavanje životinja</p>
    </div>
  </div>
</main>
</body>
</html> 


  
  
  
  
  