<?php
include_once('databaseconnection.php');
$error=false;
if(isset($_POST['udomi']))
{
    $Ime=mysqli_real_escape_string($con,$_POST['Ime']);
    $Prezime=mysqli_real_escape_string($con,$_POST['Prezime']);
    $Mjesto=mysqli_real_escape_string($con,$_POST['Mjesto']);
    $Adresa=mysqli_real_escape_string($con,$_POST['Adresa']);
    $Telefon=mysqli_real_escape_string($con,$_POST['Telefon']);
    $Email=mysqli_real_escape_string($con,$_POST['Email']);
    $Odgovor1=mysqli_real_escape_string($con,$_POST['Odgovor1']);
    $Odgovor2=mysqli_real_escape_string($con,$_POST['Odgovor2']);
    $Odgovor3=mysqli_real_escape_string($con,$_POST['Odgovor3']);
    $Odgovor4=mysqli_real_escape_string($con,$_POST['Odgovor4']);
    $Odgovor5=mysqli_real_escape_string($con,$_POST['Odgovor5']);
    $Životinja=mysqli_real_escape_string($con,$_POST['Životinja']);
    $ImeŽivotinje=mysqli_real_escape_string($con,$_POST['ImeŽivotinje']);
    if(!filter_has_var(INPUT_POST,'check')) 
    {
      echo '<script>alert("Niste prihvatili uvjete o udomljavanju! ")</script>';
    }
    else
    {
      if(!preg_match("/^[a-zA-Z ]+$/",$Ime))
      {
        $error=true;
        $Imeerror_msg="Neispravno ime ";
      }
      if(!preg_match("/^[a-zA-Z ]+$/", $Prezime))
      {
        $error=true;
        $Prezimeerror_msg="Neispravno prezime";
      }
      if(!preg_match("/^[a-zA-Z ]+$/", $Mjesto))
      {
        $error=true;
        $Mjestoerror_msg="Neispravno mjesto";
      }
      if(!preg_match("/[A-Za-z0-9]+$/", $Adresa))
      {
        $error=true;
        $Adresaerror_msg="Neispravna adresa";
      }
      if(!preg_match("/^[0-9]*$/", $Telefon))
      {
        $error=true;
        $Telefonerror_msg="Samo brojevi";
      }
      if(!filter_var($Email,FILTER_VALIDATE_EMAIL))
      {
        $error=true;
        $Emailerror_msg="Neispravna Email adresa";
      }
      else
      {
        $sql = "SELECT * FROM obrazac WHERE Email='$Email' LIMIT 1";
        $result = mysqli_query($con, $sql);
        if (mysqli_num_rows($result) > 0) 
        {
            $error=true;
            $Emailerror_msg="Postojeća adresa";
        }
      }
    if(!preg_match("/^[a-zA-Z ]+$/",$Odgovor1))
    {
      $error=true;
      $Odgovor1error_msg="Neispravan odgovor";
    }
    if(!preg_match("/^[a-zA-Z ]+$/",$Odgovor2))
    {
      $error=true;
      $Odgovor2error_msg="Neispravan odgovor";
    }
    if(!preg_match("/^[0-9]*$/",$Odgovor3))
    {
      $error=true;
      $Odgovor3error_msg="Neispravan odgovor";
    }
    if(!preg_match("/^[a-zA-Z ]+$/",$Odgovor4))
    {
      $error=true;
      $Odgovor4error_msg="Neispravan odgovor";
    }
    if(!preg_match("/^[a-zA-Z ]+$/",$Odgovor5))
    {
      $error=true;
      $Odgovor5error_msg="Neispravan odgovor";
    }
    if(!preg_match("/^[a-zA-Z ]+$/",$ImeŽivotinje))
    {
      $error=true;
      $ImeŽivotinje="Neispravan odgovor";
    }
    if (!$error) 
    {
      if(mysqli_query($con, "INSERT INTO obrazac(Ime, Prezime, Mjesto, Adresa, Telefon, Email, Odgovor1,Odgovor2,Odgovor3,Odgovor4,Odgovor5,Životinja,ImeŽivotinje) VALUES
        ('" . $Ime . "', '" . $Prezime . "',  '" . $Mjesto . "',  '" . $Adresa . "',  '" . $Telefon . "',  '" . $Email . "','" . $Odgovor1 . "', '" . $Odgovor2 . "',  
        '" . $Odgovor3 . "',  '" . $Odgovor4 . "',  '" . $Odgovor5 . "',  '" . $Životinja . "','".$ImeŽivotinje."')")) 
      {
        header("location:cestitka.php");
      }
      else 
      {
        $Pogresna_msg = "Nešto je pošlo po zlu, pokušavaj ponovno kasnije!";
      }
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link rel="stylesheet" href="Stilovi/styleregistrirajse.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<title>UDOMI ME</title>
</head>
<body style="background: #CCC;">
  <div class="obrazac ">
   <div class="container py-4">
    <div class="row g-0">
     <h1 class=" text-center">OBRAZAC</h1>
    <div class="col-lg-12 text-center py-1">
        <form action="udomi.php" method="POST">
          <div></div>
       
        <h4 class="offset-0">OSOBNI PODATCI</h4>

             <div class="offset-3 col-md-6 py-2">

            <input type="text" name="Ime" placeholder="Ime"  class="form-control"  required  value="<?php if($error) echo $Ime; ?>"> 
            <span class="text-danger"><?php if (isset($Imeerror_msg)) echo $Imeerror_msg; ?></span>
            </div>
            
            <div class="offset-3 col-md-6 py-2">
            <input type="text" name="Prezime" placeholder="Prezime" class="form-control" required value="<?php if($error) echo $Prezime; ?>">
            <span class="text-danger"><?php if (isset($Prezimeerror_msg)) echo $Prezimeerror_msg; ?></span>
            </div>
            
            <div class="offset-3 col-md-6 py-2">
            <input type="text" name="Mjesto" placeholder="Mjesto" class="form-control" required value="<?php if($error) echo $Mjesto; ?>"> 
            <span class="text-danger"><?php if (isset($Odgovor3error_msg)) echo $Odgovor3error_msg; ?></span>
            </div>

            
            <div class="offset-3 col-md-6 py-2">
            <input type="text" name="Adresa" placeholder="Adresa" class="form-control" required value="<?php if($error) echo $Adresa; ?>"> 
            <span class="text-danger"><?php if (isset($Adresaerror_msg)) echo $Adresaerror_msg; ?></span>
            </div>

            
            <div class="offset-3 col-md-6 py-2">
            <input type="text" name="Telefon" placeholder="Telefon" class="form-control" required value="<?php if($error) echo $Telefon; ?>"> 
            <span class="text-danger"><?php if (isset($Telefonerror_msg)) echo $Telefonerror_msg; ?></span>
            </div>

            
            <div class="offset-3 col-md-6 py-2">
            <input type="text" name="Email" placeholder="Email" class="form-control" required value="<?php if($error) echo $Email; ?>"> 
            <span class="text-danger"><?php if (isset($Emailerror_msg)) echo $Emailerror_msg; ?></span>
            </div>

            <h4 class="offset-0">UPITNIK</h4>
            <div class="offset-2 col-md-8 py-2">            
            <input type="text" name="Odgovor1" placeholder="Zašto želite udomiti?"  class="form-control"  required  value="<?php if($error) echo $Odgovor1; ?>"> 
            <span class="text-danger"><?php if (isset($Odgovor1error_msg)) echo $Odgovor1error_msg; ?></span>
    
            </div>
            
            <div class="offset-2 col-md-8 py-2">
            <input type="text" name="Odgovor2" placeholder="Jeste li prije imali kućnoga ljubimca i što se dogodilo s njim?" class="form-control" required value="<?php if($error) echo $Odgovor2; ?>">
            <span class="text-danger"><?php if (isset($Odgovor2error_msg)) echo $Odgovor2error_msg; ?></span>
            </div>
            
            <div class="offset-2 col-md-8 py-2">
            <input type="text" name="Odgovor3" placeholder="Koliko članova ima Vaša obitelj?" class="form-control" required value="<?php if($error) echo $Odgovor3; ?>"> 
            <span class="text-danger"><?php if (isset($Odgovor3error_msg)) echo $Odgovor3error_msg; ?></span>
            </div>

            
            <div class="offset-2 col-md-8 py-2">
            <input type="text" name="Odgovor4" placeholder="Jesu li svi ukućani suglasni s udomljenjem?" class="form-control" required value="<?php if($error) echo $Odgovor4; ?>"> 
            <span class="text-danger"><?php if (isset($Odgovor4error_msg)) echo $Odgovor4error_msg; ?></span>
            </div>

            <div class="offset-2 col-md-8 py-2">
            <input type="text" name="Odgovor5" placeholder="Živite li u kući ili u stanu? " class="form-control" required value="<?php if($error) echo $Odgovor4; ?>"> 
            <span class="text-danger"><?php if (isset($Odgovor4error_msg)) echo $Odgovor4error_msg; ?></span>
            </div>

            <div class="offset-2 col-md-8 py-2">
                  <div class="form">
                  <select name="Životinja"class="form-select" id="floatingSelectGrid" aria-label="Floating label select example">
                      <option disabled>Odaberi životinju koju želiš udomiti</option>
                      <option value="Pas">Pas</option>
                      <option value="Mačka" >Mačka</option>
                   </select>
                </div>
            </div>  
            
            <div class="offset-2 col-md-8 py-2">
            <input type="text" name="ImeŽivotinje" placeholder="Navedite ime životinje koju želite udomiti." class="form-control" required value="<?php if($error) echo $Odgovor5; ?>"> 
            <span class="text-danger"><?php if (isset($Odgovor5error_msg)) echo $Odgovor5error_msg; ?></span>
            </div>

           <div class="offset-2 col-md-8 py-2">
                  <input name="check" class="form-check-input" type="checkbox" value="" id="myCheck" >
                  <label class="form-check-label" for="myCheck">
                  Prihvaćate uvjete o udomljavanju
                 </label>
                 
            </div>

        <div class="py-4">
            <span class="text-danger"><button type="submit" name="udomi" class="rounded-3">UDOMI</button>
        </div>
        </form>
       
        
   </div>
  </div>
</body>
</html>