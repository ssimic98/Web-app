<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link rel="stylesheet" href="styleOpis.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<title>UDOMI ME</title>
<body style="background: #CCC;">
  <div class="opis">
   <div class="container py-4">
    <div class="row g-0">
        <div class="offset-1 col-lg-10" style="font-size:20px">
          <h1 class="offset-3">UVJETI UDOMLJAVANJA</h1>
          <b>1.</b>Svi ukućani moraju imati apsolutno pozitivan stav o dolasku životinje u obitelj te biti svjesni da je životinja zajednička odgovornost sve dok živi <br>
          <b>2.</b>Potrebna su Vam financijska sredstva za hranu, cjepiva i eventualna liječenja kod veterinara. <br>
          <b>3.</b>Ograda oko kuće mora biti dovoljne visine i dobro postavljena kako životinja ne bi mogla izaći.<br>
          <b>4.</b>Morate imati rješenje za čuvanje životinje pri bilo kakvom Vašem duljem odsutstvu.  <br>
          <b>5.</b>Kod udomljavanja prvenstveno su bitne karakterne osobine životinje jer moraju odgovarati Vašem tempu života.<br>
          <b>6.</b>Životinje morate pravilno odgojiti, socijalizirati i, ako je potrebno, školovati.<br>
          <b>7.</b>Životinju udomljavate za zauvijek, a ne dok ne ostarite/selite/nađete dečka ili djevojku/dobijete novog člana obitelji/Vam ne dosadi/poželite nabaviti novo životinju.<br>
          <b>8.</b>Ukoliko ne možete ispoštovati navedeno - predlažemo da ipak još jednom dobro  promislite o udomljavanju.<br>
          <br>
        </div>
      </div>
    </div>
   </div>
  </div>
</body>
</html> 