<?php 
session_start();  
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link rel="stylesheet" href="Stilovi/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<title>UDOMI ME</title>
</head>
<body>
  <nav class="navbar fixed-top navbar-expand-lg navbar-light p-md-2"style=" background:rgb(176, 128, 225)"
  >
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="Slike/ikonica.jpg" alt="Logo" width="60" height="60">UDOMI ME
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">
        <div class="mx-auto"></div>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="link" href="pocetna.php">POČETNA</a>
          </li>
          <li class="nav-item">
            <a class="link" href="zastoudomiti.php">ZAŠTO UDOMITI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="psi.php">PSI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="macke.php">MAČKE</a>
          </li>
          <li class="nav-item">
            <a class="link " href="udomi.php">UDOMI</a>
          </li>
          <li class="nav-item">
            <a class="link " href="uvjetiUdomljavanja.php">UVJETI O UDOMLJAVANJU</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div
    class="image w-100 vh-100 d-flex  align-items-center">
    <div class="content text-center">
      <h1 >UDOMI</h1>
      <div class="paragraph1">Iako su ljudi sve više osviješteni o tome da životinje nisu roba kojom se trguje, već živa 
        bića čija jedinstvenost, 
        privrženost i vrijednost nema cijenu, još uvijek mnogi ljudi imaju naviku kupovati pse i druge životinje. 
        Životinje često kupuju kao darove za rođendane, blagdane i slične prigode, pri čemu se ne vodi računa je li 
        dijete ili odrasla osoba koja dobiva životinju spremna za nju preuzeti dugogodišnju skrb i odgovornost ili će 
        je odbaciti nakon što joj dosadi. Većina ljudi pritom ne razmišlja o tome kako su uzgoj i trgovina životinjama 
        povezani su s ogromnom patnjom i smrću životinja, ne samo onih koje se prodaju, već i onih koje čekaju udomljenje. 
        Kada ljudi kupuju životinju, oduzimaju napuštenim životinjama u skloništima šansu za udomljavanjem. </div>
    </div>
  </div>
</body>
   
</html> 

  
  
  
  
  